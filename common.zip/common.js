function sum() {
var a=(parseInt(document.getElementById("text1").value));
var b=(parseInt(document.getElementById("text2").value));
  var result = a + b;
document.getElementById("text3").value=result;
}
function sub() {
var a=(parseInt(document.getElementById("text1").value));
var b=(parseInt(document.getElementById("text2").value));
  var result = a - b;
document.getElementById("text3").value=result;
}
function mul() {
  var a = (parseInt(document.getElementById("text1").value));
  var b = (parseInt(document.getElementById("text2").value));
  var result = a * b;
  document.getElementById("text3").value = result;
}
function div() {
  var a = (parseInt(document.getElementById("text1").value));
  var b = (parseInt(document.getElementById("text2").value));
  var result = a / b;
  document.getElementById("text3").value = result;
}